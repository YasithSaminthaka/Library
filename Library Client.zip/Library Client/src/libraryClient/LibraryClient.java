/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryClient;

import javax.swing.JFrame;


public class LibraryClient {
    public static void main(String[] args) {
        WelcomePage welcome = new WelcomePage();
        welcome.setVisible(true);
        welcome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

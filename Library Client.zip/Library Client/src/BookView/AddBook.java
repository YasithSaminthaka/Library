
package BookView;

import AuthorView.AddAuthor;
import AuthorView.EditAndDeleteAuthor;
import Connector.ServerConnector;
import Controller.AuthorController;
import Controller.BookController;
import Model.Author;
import Model.Book;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.text.TextAction;

public class AddBook extends javax.swing.JFrame {

    public AddBook() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        bookIdText = new javax.swing.JTextField();
        bookTitleText = new javax.swing.JTextField();
        bookPublisherText = new javax.swing.JTextField();
        bookCopiesText = new javax.swing.JTextField();
        bookPagesText = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookDescriptionText = new javax.swing.JTextArea();
        addBookButton = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        AuthorNameCombo = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(java.awt.Color.white);

        jLabel1.setBackground(java.awt.Color.black);
        jLabel1.setFont(new java.awt.Font("Bitstream Vera Sans Mono", 1, 24)); // NOI18N
        jLabel1.setForeground(java.awt.Color.blue);
        jLabel1.setText("Add books");

        bookIdText.setBackground(java.awt.Color.white);
        bookIdText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookIdTextActionPerformed(evt);
            }
        });

        bookTitleText.setBackground(java.awt.Color.white);
        bookTitleText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookTitleTextActionPerformed(evt);
            }
        });

        bookPublisherText.setBackground(java.awt.Color.white);
        bookPublisherText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookPublisherTextActionPerformed(evt);
            }
        });

        bookCopiesText.setBackground(java.awt.Color.white);
        bookCopiesText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookCopiesTextActionPerformed(evt);
            }
        });

        bookPagesText.setBackground(java.awt.Color.white);
        bookPagesText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookPagesTextActionPerformed(evt);
            }
        });

        bookDescriptionText.setBackground(java.awt.Color.white);
        bookDescriptionText.setColumns(20);
        bookDescriptionText.setRows(5);
        jScrollPane1.setViewportView(bookDescriptionText);

        addBookButton.setBackground(java.awt.Color.white);
        addBookButton.setFont(new java.awt.Font("Bitstream Vera Sans Mono", 1, 13)); // NOI18N
        addBookButton.setForeground(java.awt.SystemColor.textText);
        addBookButton.setText("Add Book");
        addBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBookButtonActionPerformed(evt);
            }
        });

        jLabel7.setBackground(java.awt.Color.black);
        jLabel7.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel7.setForeground(java.awt.SystemColor.textText);
        jLabel7.setText("Description");

        jLabel6.setBackground(java.awt.Color.black);
        jLabel6.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel6.setForeground(java.awt.SystemColor.textText);
        jLabel6.setText("Pages");

        jLabel5.setBackground(java.awt.Color.black);
        jLabel5.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel5.setForeground(java.awt.SystemColor.textText);
        jLabel5.setText("Copies");

        jLabel4.setBackground(java.awt.Color.black);
        jLabel4.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel4.setForeground(java.awt.SystemColor.textText);
        jLabel4.setText("Publisher");

        jLabel3.setBackground(java.awt.Color.black);
        jLabel3.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel3.setForeground(java.awt.SystemColor.textText);
        jLabel3.setText("Book title");

        jLabel2.setBackground(java.awt.Color.black);
        jLabel2.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel2.setForeground(java.awt.SystemColor.textText);
        jLabel2.setText("Book Id");

        jLabel8.setBackground(java.awt.Color.black);
        jLabel8.setFont(new java.awt.Font("Courier 10 Pitch", 0, 16)); // NOI18N
        jLabel8.setForeground(java.awt.SystemColor.textText);
        jLabel8.setText("Book Author");

        AuthorNameCombo.setBackground(java.awt.Color.white);
        AuthorNameCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AuthorNameComboActionPerformed(evt);
            }
        });

        jButton1.setBackground(java.awt.Color.white);
        jButton1.setFont(new java.awt.Font("Bitstream Vera Sans Mono", 1, 13)); // NOI18N
        jButton1.setForeground(java.awt.SystemColor.textText);
        jButton1.setText("Add author");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        refreshButton.setBackground(java.awt.Color.white);
        refreshButton.setFont(new java.awt.Font("Bitstream Vera Sans Mono", 1, 13)); // NOI18N
        refreshButton.setForeground(java.awt.SystemColor.textText);
        refreshButton.setText("REFRESH");
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jSeparator1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(addBookButton, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(229, 229, 229))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel3))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1)
                                    .addComponent(bookPagesText)
                                    .addComponent(bookPublisherText)
                                    .addComponent(bookCopiesText)
                                    .addComponent(bookTitleText)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(bookIdText, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(AuthorNameCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(457, 457, 457)))))
                .addGap(66, 66, 66)
                .addComponent(refreshButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(380, 380, 380)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(bookIdText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(AuthorNameCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(refreshButton))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(bookTitleText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(bookPublisherText, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(bookCopiesText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(bookPagesText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(addBookButton)
                .addGap(43, 43, 43))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addBookButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBookButtonActionPerformed
         String bookId = bookIdText.getText();
         String bookTitle = bookTitleText.getText();
         String bookPublisher = bookPublisherText.getText();
         String bookCopies = bookCopiesText.getText();
         String bookPages = bookPagesText.getText();
         String bookDescription = bookDescriptionText.getText();
         String bookAuthor = (String) AuthorNameCombo.getSelectedItem();
         if(bookDescription.equals("")) {
             bookDescription = "No Description";
         }
         
         
         if(!bookPages.equals("")
                && !bookId.equals("") 
                && !bookTitle.equals("") 
                && !bookCopies.equals("") 
                && !bookAuthor.equals("")){
            try {
                
                BookController bookController = ServerConnector.getServerConnector().getBookController(); 
                
                
                int bookCopiesInt = Integer.parseInt(bookCopies);   
                int bookPagesInt = Integer.parseInt(bookPagesText.getText());
                    
            if(!bookId.equals("")){
                
                ArrayList<Book> bookList = bookController.viewAllBook();
                for ( Book books: bookList) {
                    String enterbookId= books.getBookId();
                    if(enterbookId.equals(bookId)){
                        JOptionPane.showMessageDialog(this, "Id is existing !");
                        bookIdText.setText("");
                        break;
                    } else {
                        
                        Book book = new Book(bookId , 
                                bookTitle ,
                                bookPublisher ,
                                bookCopiesInt ,
                                bookPages ,
                                bookDescription,
                                bookAuthor);
                    boolean ans = bookController.addBook(book);    
                    if(ans) {
                        JOptionPane.showMessageDialog(this, "Add Success !");
                        bookIdText.setText("");
                        bookPublisherText.setText("");
                        bookCopiesText.setText("");
                        bookPagesText.setText("");
                        bookDescriptionText.setText("");
                        bookTitleText.setText("");
                    }else {
                        JOptionPane.showMessageDialog(this, "Add Not Success !");
                    }
                    
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Empty ID !");
            }
            
            
                
                
                
                } catch (NotBoundException ex) {
                    Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
                } catch (MalformedURLException ex) {
                    Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
                } catch (RemoteException ex) {
                    Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(this, "Pleace enter correct detais !");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Pleace enter correct detais !");
                } catch (NullPointerException ex) {
                    
                }
        } else{
            JOptionPane.showMessageDialog(this, "Rechecked");
        }        
    }//GEN-LAST:event_addBookButtonActionPerformed

    private void AuthorNameComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AuthorNameComboActionPerformed
      bookTitleText.requestFocus();
     
    }//GEN-LAST:event_AuthorNameComboActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        AuthorNameCombo.removeAllItems();
        AuthorController authorController;
        try {
            authorController = ServerConnector.getServerConnector().getAuthorController();
            ArrayList<Author> authorList = authorController.viewAllAuthor();
            for(Author author : authorList) {
                String authorName = author.getAuthorName();
                AuthorNameCombo.addItem(authorName);
            }
        } catch (NotBoundException ex) {
            Logger.getLogger(editAndDeleteBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(editAndDeleteBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(editAndDeleteBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(editAndDeleteBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(editAndDeleteBook.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void bookIdTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookIdTextActionPerformed
        try { 
            String enterId = bookIdText.getText();
            if(!enterId.equals("")){
                BookController bookController = ServerConnector.getServerConnector().getBookController();
                ArrayList<Book> bookList = bookController.viewAllBook();
                for ( Book book: bookList) {
                    String bookId= book.getBookId();
                    if(bookId.equals(enterId)){
                        JOptionPane.showMessageDialog(this, "Id is existing !");
                        bookIdText.setText("");
                        break;
                    } else {
                    AuthorNameCombo.requestFocus();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Empty ID !");
            }
            
        } catch (NotBoundException ex) {
            Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (RemoteException ex) {
            Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddBook.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bookIdTextActionPerformed

    private void bookTitleTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookTitleTextActionPerformed
        String bookTitle = bookTitleText.getText();
        if(!bookTitle.equals("")) {
            bookPublisherText.requestFocus();
        } else {
            JOptionPane.showMessageDialog(this, "Pleace enter Title !");
        }
        
    }//GEN-LAST:event_bookTitleTextActionPerformed

    private void bookPublisherTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookPublisherTextActionPerformed
        if(!bookPublisherText.getText().equals("")) {
            bookCopiesText.requestFocus();
        }else {
            JOptionPane.showMessageDialog(this, "Pleace enter Publisher !");
        }
            
        
    }//GEN-LAST:event_bookPublisherTextActionPerformed

    private void bookCopiesTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookCopiesTextActionPerformed
        try {
            int copies = Integer.parseInt(bookCopiesText.getText());
            bookPagesText.requestFocus();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Pleace enter number !");
        }
        
        
    }//GEN-LAST:event_bookCopiesTextActionPerformed

    private void bookPagesTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookPagesTextActionPerformed
        try {
            int pages = Integer.parseInt(bookPagesText.getText());
            bookDescriptionText.requestFocus();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Pleace enter number !");
        }
        
    }//GEN-LAST:event_bookPagesTextActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        AddAuthor addAuthor = new AddAuthor();
        addAuthor.setVisible(true);
        addAuthor.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox AuthorNameCombo;
    private javax.swing.JButton addBookButton;
    private javax.swing.JTextField bookCopiesText;
    private javax.swing.JTextArea bookDescriptionText;
    private javax.swing.JTextField bookIdText;
    private javax.swing.JTextField bookPagesText;
    private javax.swing.JTextField bookPublisherText;
    private javax.swing.JTextField bookTitleText;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton refreshButton;
    // End of variables declaration//GEN-END:variables
}

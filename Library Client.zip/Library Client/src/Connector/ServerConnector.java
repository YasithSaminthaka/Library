
package Connector;

import Controller.AdminController;
import Controller.AuthorController;
import Controller.BookController;
import Controller.LibrayController;
import Controller.OperatorController;
import Controller.UserController;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;


public class ServerConnector {
   private static ServerConnector serverConnector;
    private LibrayController librayController;
    private UserController userController;
    private AuthorController authorController;
    private BookController bookController;
    private OperatorController operatorController;
    private AdminController adminController;
    
    private ServerConnector() throws NotBoundException, MalformedURLException, RemoteException{
        librayController = (LibrayController) Naming.lookup("rmi://localhost:5050/LibraryServer");
    }
    public static ServerConnector getServerConnector() throws NotBoundException, MalformedURLException, RemoteException{
        if(serverConnector==null){
            serverConnector=new ServerConnector();
        }
        return serverConnector;
        
    }
    /*
    public AuthorController getAuthorController() throws RemoteException, SQLException, ClassNotFoundException {
        if(authorController==null){
            authorController = librayController.getAuthorController();
        }
        return authorController;
    }

    */
    public UserController getUserController() throws RemoteException, SQLException, ClassNotFoundException {
        if(userController==null){
            userController=librayController.getUserController();
        }
        return userController;
    }
    
    public BookController getBookController() throws RemoteException, SQLException, ClassNotFoundException {
        if(bookController==null){
            bookController = librayController.getBookController();
        }
        return bookController;
    }
    public OperatorController getOperatorController() throws RemoteException, SQLException, ClassNotFoundException {
        if(operatorController==null){
            operatorController = librayController.getOperatorController();
        }
        return operatorController;
    }
    
    public AuthorController getAuthorController () throws RemoteException, SQLException, ClassNotFoundException {
        if(authorController == null) {
            authorController = librayController.getAuthorController();
        }
        return authorController;
    }
    public AdminController getAdminController() throws RemoteException, SQLException, ClassNotFoundException {
        if(adminController == null) {
            adminController = librayController.getAdminController();
        }
        return adminController;
    }
   
}

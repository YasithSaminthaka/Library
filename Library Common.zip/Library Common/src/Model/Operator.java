/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;

/**
 *
 * @author yasith
 */
public class Operator implements Serializable {
    private String operartorName;
    private String operatorId;
    private String operatorDescription;
    private String operatorPassword;
    public Operator() {
        
    }
    public Operator(String operatorName, String operatorId, String operatorDescription, String operatorPassword) {
        this.operartorName = operatorName;
        this.operatorId = operatorId;
        this.operatorDescription = operatorDescription;
        this.operatorPassword = operatorPassword;
    }   

    public void setOperartorName(String operartorName) {
        this.operartorName = operartorName;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public void setOperatorDescription(String operatorDescription) {
        this.operatorDescription = operatorDescription;
    }

    public void setOperatorPassword(String operatorPassword) {
        this.operatorPassword = operatorPassword;
    }
    public String getOperatorName() {
        return operartorName;
    }
    public String getOperatorPassword() {
        return operatorPassword;
    }
    public String getOpratorId() {
        return operatorId;
    }
    
    public String getOperatorDescription() {
        return operatorDescription;
    }
}

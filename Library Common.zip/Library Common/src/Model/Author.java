
package Model;

import java.io.Serializable;


public class Author implements Serializable{
    
    private String authorName;
    private String authorId;
    private String authorDescription;
    
    public Author(String authorName , String authorId , String authorDescription) {
        this.authorName = authorName;
        this.authorId = authorId;
        this.authorDescription = authorDescription;
    }
    public String getAuthorName(){
        return authorName;
    }
    
    public String getAuthorId(){
        return authorId;
    }
    
    public String getAuthorDescription(){
        return authorDescription;
    }
}

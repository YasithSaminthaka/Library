
package Model;

import java.io.Serializable;
import java.sql.Date;


public class Book implements Serializable {
    private String bookID;
    private String bookTitle;
    private String bookPublisher;
    private int numberOfCopies;
    private String bookPages;
    private String bookDescription;
    private String bookAuthor;
    private String LendUserId;
    private int penalty;
    private String LendBookId;
    private String LendBookTitle;
    private Date lastdate;
    private int timeLimit;
    private Date firstDate;
    private Date date;
    private String timeLimitOperatorId;
    private Date numberOfBookChangeDate;
    private int numberOfBook;

    public Book(Date numberOfBookChangeDate, int numberOfBook) {
        this.numberOfBookChangeDate = numberOfBookChangeDate;
        this.numberOfBook = numberOfBook;
    }

    public Date getNumberOfBookChangeDate() {
        return numberOfBookChangeDate;
    }

    public void setNumberOfBookChangeDate(Date numberOfBookChangeDate) {
        this.numberOfBookChangeDate = numberOfBookChangeDate;
    }

    public int getNumberOfBook() {
        return numberOfBook;
    }

    public void setNumberOfBook(int numberOfBook) {
        this.numberOfBook = numberOfBook;
    }
    
    public Book(){
        
    }
    
    public Book(int timeLimit , Date date , String timeLimitOperatorId) {
        this.timeLimit =timeLimit;
        this.date = date;
        this.timeLimitOperatorId =timeLimitOperatorId;
    }
    public int getTimeLimit() {
        return timeLimit;
    }
    public Date getDate() {
        return date;
    }
    public String getTimeLimitOperatorId() {
        return timeLimitOperatorId;
    }
    
    public Book(String lendUserId, 
            String lendBookId , 
            String lendBookTitle, 
            Date firstDate , 
            
            Date lastDate
            ) {
        
        this.LendBookId = lendBookId;
        this.LendBookTitle = lendBookTitle;
        this.LendUserId = lendUserId;
        this.lastdate = lastdate;
        this.firstDate= firstDate;
    }
    
    public Book(String bookID 
            , String bookTitle ,
            String bookPublisher 
            , int numberOfCopies 
            , String bookPages 
            , String bookDescription
            , String bookAuthor) {
        
        this.bookID = bookID;
        this.bookTitle = bookTitle;
        this.bookPublisher = bookPublisher;
        this.numberOfCopies = numberOfCopies;
        this.bookPages = bookPages;
        this.bookDescription = bookDescription;
        this.bookAuthor = bookAuthor;
        
    }
    public String getBookId() {
        return bookID;
    }
    public String getBookTitle() {
        return bookTitle;
    }
    public String getBookPublisher() {
        return bookPublisher;
    }
    public int getNumberOfCopies() {
        return numberOfCopies;
    }
    public String getBookPages() {
        return bookPages;
    }
    public String getBookDescription() {
        return bookDescription;
    }
    public String getBookAuthor() {
        return bookAuthor;
    }
    
    public int getLendOperatorId() {
        return penalty;
    }
    public Date getLastDate() {
        return lastdate;
    }
    public String getLendBookId() {
        return LendBookId;
    }
    public String getLendUserId() {
        return LendUserId;
    }
    public String getLendBookTitle() {
        return LendBookTitle;
    }
    public Date getFirstDate() {
        return firstDate;
    }
}


package Model;

import java.io.Serializable;
import java.sql.Date;


public class User implements Serializable {
    private String userId;
    private String userName;
    private String userAddress;
    private String userNIC;
    private String userAdmissionNumber;
    private Date userRegisteredDate;
    private String UserDescription;
    private String userTel;
    private String userEmail;
    
    
    public User(){
        //constructor override
    }
    public User(String userId 
            , String userName 
            , String userAddress 
            , String userNIC 
            , String userAdmissionNumber 
            , String userTel 
            , String userEmail
            , String UserDescription ) {
        
        this.userId = userId;
        this.userAddress = userAddress;
        this.userAdmissionNumber = userAdmissionNumber;
        this.userNIC = userNIC;
        this.userName = userName;
        this.UserDescription = UserDescription;
        this.userTel = userTel;
        this.userEmail = userEmail;
    }
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId ){
        this.userId=userId;
    }    
    public String getUserName() {
        return userName;
    }
    
    public String getUserAddress() {
        return userAddress;
    }
    
    public String getUserAdmisionNumber() {
        return userAdmissionNumber;
    }
    
    public String getUserNIC() {
        return userNIC;
    }
    
    public String getUserDescription() {
        return UserDescription;
    }
    
    public String getUserTel() {
        return userTel;
    }
    
    public String getUserEmail() {
        return userEmail;
    }
    
    public Date getUserRegisteredDate() {
        return null;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Book;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author yasith
 */
public interface BookController extends Remote{
    public boolean addBook (Book book) throws RemoteException , SQLException , ClassNotFoundException;
    public Book searchBook(String book) throws RemoteException , SQLException , ClassNotFoundException;
    public Book searchNameBook(String book) throws RemoteException , SQLException , ClassNotFoundException;
    public boolean updateBook(Book book) throws RemoteException , SQLException , ClassNotFoundException;
    public boolean deleteBook(String book) throws RemoteException , SQLException , ClassNotFoundException;
    public ArrayList<Book> viewAllBook() throws RemoteException , SQLException , ClassNotFoundException; 
    public ArrayList<Book> viewLandBook() throws RemoteException , SQLException , ClassNotFoundException;//no declare
    public boolean addToLandBook(Book book) throws RemoteException , SQLException , ClassNotFoundException;
    public boolean addToReturnBook(String bookId , String userId , String operatorPassword) throws RemoteException , SQLException , ClassNotFoundException; //NO DECLARE
    public long penaltyController(int dueDate , long penalty)throws RemoteException , SQLException , ClassNotFoundException;   //NO DECLARE
    public ArrayList<Book> searchLandBook(String bookIs) throws RemoteException , SQLException , ClassNotFoundException;
    public int timeLimit(Book book) throws RemoteException , SQLException , ClassNotFoundException;
    public Book numberOfBooks() throws RemoteException , SQLException , ClassNotFoundException;
    public int changeNumberOfBooks(int number) throws RemoteException , SQLException , ClassNotFoundException;
    
}

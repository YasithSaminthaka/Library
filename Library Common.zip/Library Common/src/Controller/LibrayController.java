
package Controller;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;


public interface LibrayController extends Remote{
    public UserController getUserController() throws RemoteException , SQLException , ClassNotFoundException;
    public BookController getBookController() throws RemoteException , SQLException , ClassNotFoundException;
    public AuthorController getAuthorController() throws RemoteException , SQLException , ClassNotFoundException;
    public OperatorController getOperatorController() throws RemoteException , SQLException , ClassNotFoundException;
    public AdminController getAdminController() throws RemoteException , SQLException , ClassNotFoundException;
}

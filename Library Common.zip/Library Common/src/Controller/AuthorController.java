
package Controller;

import Model.Author;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;


public interface AuthorController extends Remote{
    public boolean addAuthor(Author author) throws SQLException , ClassNotFoundException , RemoteException;
    public boolean updateAuthor(Author author) throws SQLException , ClassNotFoundException , RemoteException;
    public boolean deleteAuthor(String authorName) throws SQLException , ClassNotFoundException , RemoteException;
    public Author searchAuthor(String authorName) throws SQLException , ClassNotFoundException , RemoteException;
    public ArrayList<Author> viewAllAuthor() throws SQLException , ClassNotFoundException , RemoteException;

}

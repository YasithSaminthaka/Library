/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Operator;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author yasith
 */
public interface OperatorController extends Remote{
    public boolean addOperator(Operator operator) throws RemoteException , SQLException , ClassNotFoundException;
    public boolean updateOperator(Operator operator) throws RemoteException , SQLException , ClassNotFoundException;
    public boolean deleteOperator(String operatorName) throws RemoteException , SQLException , ClassNotFoundException;
    public Operator searchOperator(String operatorName) throws RemoteException , SQLException , ClassNotFoundException;
    public ArrayList<Operator> viewAllOperator() throws RemoteException , SQLException , ClassNotFoundException;
    public boolean operatorLogin(String password) throws RemoteException , SQLException , ClassNotFoundException;
}

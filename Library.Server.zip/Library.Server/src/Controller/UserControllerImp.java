/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DbAccess.UserDbAccess;
import Model.User;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.SQLException;
import java.util.ArrayList;


public class UserControllerImp extends UnicastRemoteObject implements UserController {
    private UserDbAccess userDbAccess = new UserDbAccess();
    public UserControllerImp() throws RemoteException {
        super();
    }

    @Override
    public boolean addUser(User user) throws SQLException, ClassNotFoundException, RemoteException {
        return userDbAccess.addUser(user);
    }

    @Override
    public boolean deleteUser(String userId) throws SQLException, ClassNotFoundException, RemoteException {
        return userDbAccess.deleteUser(userId);
    }

    @Override
    public boolean updateUser(User user) throws SQLException, ClassNotFoundException, RemoteException {
        return userDbAccess.updateUser(user);
    }

    @Override
    public User searchUser(String userId) throws SQLException, ClassNotFoundException, RemoteException {
        return userDbAccess.searchUser(userId);
    }

    @Override
    public ArrayList<User> viewAllUser() throws SQLException, ClassNotFoundException, RemoteException {
        return new UserDbAccess().viewAllUser();
    }
    
}

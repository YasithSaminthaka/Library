
package Controller;

import DbAccess.AuthorDbAccess;
import Model.Author;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.SQLException;
import java.util.ArrayList;


public class AuthorControllerImp extends UnicastRemoteObject implements AuthorController{
   public AuthorControllerImp() throws RemoteException {
       
   }

    @Override
    public boolean addAuthor(Author author) throws SQLException, ClassNotFoundException, RemoteException {
        return new AuthorDbAccess().addAuthor(author);
    }

    @Override
    public boolean updateAuthor(Author author) throws SQLException, ClassNotFoundException, RemoteException {
        return new AuthorDbAccess().updateAuthor(author);
    }

    @Override
    public boolean deleteAuthor(String authorName) throws SQLException, ClassNotFoundException, RemoteException {
        return new AuthorDbAccess().deleteAuthor(authorName);
    }

    @Override
    public Author searchAuthor(String authorName) throws SQLException, ClassNotFoundException, RemoteException {
        return new AuthorDbAccess().searchAuthor(authorName);
    }

    @Override
    public ArrayList<Author> viewAllAuthor() throws SQLException, ClassNotFoundException, RemoteException {
        return new AuthorDbAccess().viewAllAuthor();
    }
    
}

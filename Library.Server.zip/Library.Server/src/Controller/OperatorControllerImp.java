
package Controller;

import DbAccess.OperatorDbAccess;
import Model.Operator;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.SQLException;
import java.util.ArrayList;


public class OperatorControllerImp  extends UnicastRemoteObject implements OperatorController{
    public OperatorControllerImp() throws RemoteException{
        
    }

    @Override
    public boolean addOperator(Operator operator) throws RemoteException, ClassNotFoundException, SQLException {
        return new OperatorDbAccess().addOperator(operator);
    }

    @Override
    public boolean updateOperator(Operator operator) throws ClassNotFoundException, SQLException , RemoteException {
        return new OperatorDbAccess().updateOperator(operator);
    }

    @Override
    public boolean deleteOperator(String operatorName) throws ClassNotFoundException, SQLException, RemoteException  {
        return new OperatorDbAccess().deleteOperator(operatorName);
    }

    @Override
    public Operator searchOperator(String operatorName) throws ClassNotFoundException, SQLException, RemoteException  {
        return new OperatorDbAccess().searchOperator(operatorName);
    }

    @Override
    public ArrayList<Operator> viewAllOperator() throws RemoteException, SQLException, ClassNotFoundException {
        return new OperatorDbAccess().viewAllOperator();
    }

    @Override
    public boolean operatorLogin(String password) throws RemoteException, SQLException, ClassNotFoundException {
        
        String operatorLogin = new OperatorDbAccess().operatorLogin(password);
        if(operatorLogin == password){
            return true;
        }
        else
        return false;
    }

}

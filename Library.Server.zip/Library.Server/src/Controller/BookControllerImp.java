/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DbAccess.BookDbAccess;
import Model.Book;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author yasith
 */
class BookControllerImp extends UnicastRemoteObject implements BookController{
    public BookControllerImp() throws RemoteException {
        
    }

    @Override
    public boolean addBook(Book book) throws RemoteException, ClassNotFoundException, SQLException {
        return new BookDbAccess().addBook(book);
    }

    @Override
    public Book searchBook(String bookId) throws RemoteException, ClassNotFoundException, SQLException {
        return new BookDbAccess().searchBook(bookId);
    }

    @Override
    public boolean updateBook(Book book) throws RemoteException, ClassNotFoundException, SQLException {
        return new BookDbAccess().updateBook(book);
    }

    @Override
    public boolean deleteBook(String bookId) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().deleteBook(bookId);
    }

    @Override
    public ArrayList<Book> viewAllBook() throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().viewAllBooks();
    }

    @Override
    public ArrayList<Book> viewLandBook() throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().viewLandBook();
    }

    

    @Override
    public long penaltyController(int dueDate , long penalty) throws RemoteException, SQLException, ClassNotFoundException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean addToLandBook(Book book) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().addToLandBook(book);
    }

    @Override
    public boolean addToReturnBook(String bookId, String userId, String operatorPassword) throws RemoteException, SQLException, ClassNotFoundException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<Book> searchLandBook(String userId) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().searchLandBook(userId);
    }

    @Override
    public int timeLimit(Book book) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().timeLimit(book);
    }

    @Override
    public Book searchNameBook(String book) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().searchNameBook(book);
    }

    @Override
    public Book numberOfBooks() throws RemoteException, SQLException, ClassNotFoundException {
     return new BookDbAccess().numberOfBook();
    }

    @Override
    public int changeNumberOfBooks(int number) throws RemoteException, SQLException, ClassNotFoundException {
        return new BookDbAccess().changeNumberOfBook(number);
    }
    
}


package Controller;


import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.sql.SQLException;

public class LibraryImp extends UnicastRemoteObject implements LibrayController {
    public LibraryImp() throws RemoteException {
        
    }

    //Override method of Libray controller
    @Override
    public UserController getUserController() throws RemoteException {
        return new UserControllerImp();
    }

    @Override
    public BookController getBookController() throws RemoteException {
        return new BookControllerImp() ;
    }

    @Override
    public AuthorController getAuthorController() throws RemoteException {
        return new AuthorControllerImp();
    }

    //method use for only admin tasks
    @Override
    public OperatorController getOperatorController() throws RemoteException {
        return new OperatorControllerImp();
    }

    @Override
    public AdminController getAdminController() throws RemoteException {
        return new AdminControllerImp();
    }
    
    
}

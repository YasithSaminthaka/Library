
package DbAccess;

import Model.Book;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BookDbAccess {
    public boolean addBook(Book book) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "insert into Book values (?,?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, book.getBookId());
        preparedStatement.setObject(2, book.getBookTitle());
        preparedStatement.setObject(3, book.getBookPublisher());
        preparedStatement.setObject(4, book.getNumberOfCopies());
        preparedStatement.setObject(5, book.getBookPages());
        preparedStatement.setObject(6, book.getBookDescription());
        preparedStatement.setObject(7, book.getBookAuthor());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }
    public Book searchBook(String bookId) throws ClassNotFoundException, SQLException{
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Select * from Book where bookId='" + bookId + "'";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        if(rst.next()){
            Book book = new Book(rst.getString("bookId"), rst.getString("bookTitle")
                    , rst.getString("bookPublisher"),rst.getInt("noOfCopies")
                    , rst.getString("bookPages"), rst.getString("bookDescription") , rst.getString("bookAuthor"));
            return book;
        }
        else
            return null;
    }
    public boolean updateBook(Book book) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Update Book set bookId= ? , bookTitle = ? , bookPublisher = ?"
                + " , noOfCopies=? , bookPages=? , bookDescription=? , bookAuthor=? where BookId=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, book.getBookId());
        preparedStatement.setObject(2, book.getBookTitle());
        preparedStatement.setObject(3, book.getBookPublisher());
        preparedStatement.setObject(4, book.getNumberOfCopies());
        preparedStatement.setObject(5, book.getBookPages());
        preparedStatement.setObject(6, book.getBookDescription());
        preparedStatement.setObject(7, book.getBookAuthor());
        preparedStatement.setObject(8, book.getBookId());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }
    
    public boolean deleteBook(String bookId) throws SQLException, ClassNotFoundException {
        String sql = "Delete from Book where bookId='"+bookId+"'";
        Connection connection = DbConnection.DBConnection.getConnection();
        Statement stm = connection.createStatement();
        int res = stm.executeUpdate(sql);
        return res > 0;
    }
    public ArrayList<Book> viewAllBooks() throws ClassNotFoundException, SQLException {
       Connection connection = DbConnection.DBConnection.getConnection();
       String sql = "select * from Book";
       Statement statement = connection.createStatement();
       ResultSet rst = statement.executeQuery(sql);
       ArrayList<Book> bookList = new ArrayList<>();
       while(rst.next()) {
           Book book = new Book(rst.getString("bookId"), rst.getString("bookTitle")
                    , rst.getString("bookPublisher")
                    ,rst.getInt("noOfCopies")
                    , rst.getString("bookPages")
                    , rst.getString("bookDescription")
                    , rst.getString("bookAuthor"));
           bookList.add(book);
       }
       return bookList;
    }
    
    public ArrayList<Book> viewLandBook() throws ClassNotFoundException, SQLException{
       Connection connection = DbConnection.DBConnection.getConnection();
       String sql = "select * from lendBook";
       Statement statement = connection.createStatement();
       ResultSet rst = statement.executeQuery(sql);
       ArrayList<Book> bookList = new ArrayList<>();
       while(rst.next()) {
           Book book = new Book(rst.getString("userId"),rst.getString("bookId"),rst.getString("bookTitle"),rst.getDate("lastdate"),rst.getDate("firstDate"));
           bookList.add(book);
       }
       return bookList;
    }
    
    public boolean addToLandBook(Book book) throws SQLException, ClassNotFoundException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "insert into lendBook values(?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, book.getLendUserId());
        preparedStatement.setObject(2, book.getLendBookId());
        preparedStatement.setObject(3, book.getBookTitle());
        preparedStatement.setObject(4, book.getLastDate());
        preparedStatement.setObject(5, book.getLendOperatorId());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }
    public ArrayList<Book> searchLandBook(String userId) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "select * from lendBook where userId='"+userId+"'";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        ArrayList<Book> bookList = new ArrayList<>();
        while(resultSet.next()){
            Book book = new Book(resultSet.getString("userId"), resultSet.getString
        ("bookId"), resultSet.getString("bookTitle"), resultSet.getDate("lastdate")
                , resultSet.getDate("firstDate"));
                bookList.add(book);
        
        }
        return bookList;
    }
    public int timeLimit(Book book) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "insert into timeLimit values(?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, book.getTimeLimit());
        preparedStatement.setObject(2, book.getDate());
        preparedStatement.setObject(3, book.getTimeLimitOperatorId());
        int a = preparedStatement.executeUpdate();
        return a;
    }
    public Book searchNameBook(String name)  throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Select * from Book where bookTitle='" + name + "'";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        
        if(rst.next()){
            Book book = new Book(rst.getString("bookId"), rst.getString("bookTitle")
                    , rst.getString("bookPublisher"),rst.getInt("noOfCopies")
                    , rst.getString("bookPages"), rst.getString("bookDescription") , rst.getString("bookAuthor"));
            return book;
        }
        else
            return null;
    }
    public Book numberOfBook()  throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Select * from numberOfBooks";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        if(rst.next()){
            Book book = new Book(rst.getDate("date"),rst.getInt("number"));  
            return book;
        } else return null;
        
    }
    public int changeNumberOfBook(int number) throws ClassNotFoundException, SQLException  {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "update numberOfBooks set number ='"+number+"' where number >0";
        Statement statement = connection.createStatement();     
        int a = statement.executeUpdate(sql);
        return a;
    }
}

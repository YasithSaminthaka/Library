
package DbAccess;

import Model.Operator;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class OperatorDbAccess {
    public boolean addOperator(Operator operator) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "insert into Operator values (?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, operator.getOperatorName());
        preparedStatement.setObject(2, operator.getOpratorId());
        preparedStatement.setObject(3, operator.getOperatorDescription());
        preparedStatement.setObject(4, operator.getOperatorPassword());
        int res = preparedStatement.executeUpdate();
        return res>0;    
    }
    
    public Operator searchOperator(String operatorId)
            throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "select * from Operator where operatorId='"+operatorId+"'";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        if (resultSet.next()){
            Operator operator = new Operator(resultSet.getString("operatorName")
                    , resultSet.getString("operatorId") ,resultSet.getString("operatorDescription")
                    , resultSet.getString("operatorPassword"));
            return operator;
        }
        else return null;
    }
    
    public boolean deleteOperator(String operatorName)
            throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Delete  From Operator where operatorId='" + operatorName+ "'";
        Statement statement = connection.createStatement();
        int a = statement.executeUpdate(sql);
        return a>0; 
    }
    
    public boolean updateOperator(Operator operator) 
            throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "update Operator set operatorName= ?, operatorDescription = ? , operatorPassword= ? where operatorId=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, operator.getOperatorName());
        preparedStatement.setObject(2, operator.getOperatorDescription());
        preparedStatement.setObject(3, operator.getOperatorPassword());
        preparedStatement.setObject(4, operator.getOpratorId());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }
    public ArrayList<Operator> viewAllOperator() throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "select * from Operator";
        Statement statement = connection.createStatement();
        ArrayList<Operator> operatorList = new ArrayList<>();
        ResultSet rst = statement.executeQuery(sql);
        while(rst.next()){
            Operator operator = new Operator(rst.getString("operatorName")
                    , rst.getString("operatorId"),rst.getString("operatorDescription")
                    , rst.getString("operatorPassword"));
            
            operatorList.add(operator);
        }
        return operatorList;
    }
    
    public String operatorLogin(String password) throws ClassNotFoundException, SQLException{
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "select * from operator where id ='"+password+"'";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        String a = resultSet.getString("name");
        return a;
    }
}

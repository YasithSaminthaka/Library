
package DbAccess;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Model.User;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDbAccess {
    public boolean addUser(User user) throws SQLException , ClassNotFoundException , RemoteException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "INSERT INTO User VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, user.getUserId());
        preparedStatement.setObject(2 , user.getUserName());
        preparedStatement.setObject(3 , user.getUserAddress());
        preparedStatement.setObject(4 , user.getUserNIC());
        preparedStatement.setObject(5 , user.getUserAdmisionNumber());
        preparedStatement.setObject(6 , user.getUserTel());
        preparedStatement.setObject(7 , user.getUserEmail());
        preparedStatement.setObject(8 , user.getUserDescription());

        int a=preparedStatement.executeUpdate();
        return a>0;
    }
    
    public User searchUser(String userId) throws ClassNotFoundException, SQLException {
        String sql = "SELECT * FROM User WHERE userId='" + userId + "'";
        Connection connection = DbConnection.DBConnection.getConnection();
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        if(rst.next()){
            User user = new User(
                    rst.getString("userId") ,
                    rst.getString("userName") , 
                    rst.getString("userAddress") ,
                    rst.getString("userNic") ,
                    rst.getString("userAdmissionNumber")  ,
                    rst.getString("userTel") ,
                    rst.getString("userEmail"), 
                    rst.getString("userDescription"));
            return user;
        }
        else{
            return null;
        }
       
    }
    
    public boolean deleteUser(String userId) throws ClassNotFoundException, SQLException {
        String sql = "delete from User where userId='" + userId+ "'";
            Connection connection = DbConnection.DBConnection.getConnection();
            Statement stm = connection.createStatement();
            int res = stm.executeUpdate(sql);
            return res > 0;
    }
    
    public boolean updateUser(User user) throws ClassNotFoundException, SQLException {
        String sql = "Update User set userName=?,userAddress=?"
                + ",userNic=?,userAdmissionNumber=? ,userTel=? , userEmail=?"
                + " ,userDescription=? where userId='"+user.getUserId()+"'";
        Connection connection = DbConnection.DBConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        
        preparedStatement.setObject(1 , user.getUserId());
        preparedStatement.setObject(2 , user.getUserAddress());
        preparedStatement.setObject(3 , user.getUserNIC());
        preparedStatement.setObject(4 , user.getUserAdmisionNumber());
        preparedStatement.setObject(5 , user.getUserTel());
        preparedStatement.setObject(6 , user.getUserEmail());
        preparedStatement.setObject(7 , user.getUserDescription());
        
        int a=preparedStatement.executeUpdate();
        return a>0;
        
    }
    public ArrayList<User> viewAllUser() throws ClassNotFoundException, SQLException {
        ArrayList<User> userList = new ArrayList<>();
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "SELECT * FROM User";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        while(rst.next()) {
            User user = new User(
                rst.getString("userId"), 
                rst.getString("userName"),
                rst.getString("userAddress"),
                rst.getString("userNic"), 
                rst.getString("userAdmissionNumber"),
                rst.getString("userTel"), 
                rst.getString("userEmail"),
                rst.getString("userDescription")); 
            userList.add(user);
        }
        
        return userList;
    }
}


package DbAccess;


import Model.Author;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AuthorDbAccess {
    public boolean addAuthor(Author author) throws SQLException, ClassNotFoundException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "insert into Author values (?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, author.getAuthorName());
        preparedStatement.setObject(2, author.getAuthorId());
        preparedStatement.setObject(3, author.getAuthorDescription());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }

    
    public boolean updateAuthor(Author author) throws SQLException, ClassNotFoundException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "update Author set  authorId = ? , authorDescription = ? where authorName =?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setObject(1, author.getAuthorId());
        preparedStatement.setObject(2, author.getAuthorDescription());
        preparedStatement.setObject(3, author.getAuthorName());
        int a = preparedStatement.executeUpdate();
        return a>0;
    }

    
    public boolean deleteAuthor(String authorName) throws SQLException, ClassNotFoundException {
         String sql = "Delete  from Author where authorName='" +  authorName + "'";
         Connection connection = DbConnection.DBConnection.getConnection();
         Statement stm = connection.createStatement();
         int res = stm.executeUpdate(sql);
         return res > 0;
    }

    
    public Author searchAuthor(String authorName) throws SQLException, ClassNotFoundException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "Select * from Author where authorName='" + authorName + "'";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        if(rst.next()){
            Author author = new Author(rst.getString("authorName"), rst.getString("authorId"), rst.getString("authorDescription"));
            return author;
        }
        else return null;
        
    }
    public ArrayList<Author> viewAllAuthor() throws ClassNotFoundException, SQLException{
       Connection connection = DbConnection.DBConnection.getConnection();
       String sql = "select * from Author";
       Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        ArrayList<Author> authorList =new ArrayList<>();
        while(rst.next()){
            Author author = new Author(rst.getString("authorName"), rst.getString("authorId"), rst.getString("authorDescription"));
            authorList.add(author);
        }
        return authorList;
    }
}

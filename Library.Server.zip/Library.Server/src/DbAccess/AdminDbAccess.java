/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DbAccess;

import Model.Admin;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author yasith
 */
public class AdminDbAccess {
    public Admin changeAdmin (String userName) throws ClassNotFoundException, SQLException {
        Connection connection = DbConnection.DBConnection.getConnection();
        String sql = "select * from Admin where adminName ='"+userName+"'";
        Statement statement = connection.createStatement();
        ResultSet rst = statement.executeQuery(sql);
        if(rst.next()){
            Admin admin = new Admin(rst.getString("adminName"), rst.getString("adminPassword"));
            return admin;
        }else return null;
    }
}

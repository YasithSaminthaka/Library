
package DbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public static Connection connection;
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        if (connection==null){
            Class.forName("com.mysql.jdbc.Driver");
             connection = DriverManager.getConnection("jdbc:mysql://localhost/Library", "root", "yasis");
        }
        return connection;
    }
}
